//
//  MessageItem.m
//  InstantMessager
//
//  Created by Duger on 13-12-20.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import "MessageItem.h"

@implementation MessageItem

@end
