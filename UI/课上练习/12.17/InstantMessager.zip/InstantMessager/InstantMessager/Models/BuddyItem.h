//
//  BuddyItem.h
//  InstantMessager
//
//  Created by Duger on 13-12-20.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BuddyItem : NSObject

@property(nonatomic, strong) NSString *buddyName;
@property(nonatomic, strong) NSString *buddyStatus;
@property(nonatomic, strong) NSString *buddyResource;

@end
