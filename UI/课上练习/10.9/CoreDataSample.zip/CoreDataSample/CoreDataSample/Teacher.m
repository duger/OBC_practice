//
//  Teacher.m
//  CoreDataSample
//
//  Created by Duger on 13-10-9.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import "Teacher.h"
#import "Student.h"


@implementation Teacher

@dynamic studentList;

@end
