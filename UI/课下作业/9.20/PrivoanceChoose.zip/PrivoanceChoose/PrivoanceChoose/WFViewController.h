//
//  WFViewController.h
//  PrivoanceChoose
//
//  Created by Duger on 13-9-20.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WFViewController : UIViewController<UIPickerViewDataSource,UIPickerViewDelegate>

@end
