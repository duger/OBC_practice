//
//  WFViewController.h
//  CoreDataPractice
//
//  Created by Duger on 13-10-11.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WFViewController : UIViewController
- (IBAction)didClickAddButton:(UIButton *)sender;
- (IBAction)didClickSelectButton:(UIButton *)sender;
- (IBAction)didClickDeleteButton:(UIButton *)sender;
- (IBAction)didClickUpdateButton:(UIButton *)sender;


@end
