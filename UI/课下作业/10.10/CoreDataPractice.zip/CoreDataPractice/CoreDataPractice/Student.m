//
//  Student.m
//  CoreDataPractice
//
//  Created by Duger on 13-10-12.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import "Student.h"


@implementation Student

@dynamic score;
@dynamic sname;

@end
