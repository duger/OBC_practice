//
//  TeacherListViewController.h
//  CoreDataPractice
//
//  Created by Duger on 13-10-11.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeacherListViewController : UITableViewController
- (IBAction)didClickCreate:(UIBarButtonItem *)sender;

@end
