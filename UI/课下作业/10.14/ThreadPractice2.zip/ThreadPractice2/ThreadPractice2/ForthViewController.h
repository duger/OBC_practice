//
//  ForthViewController.h
//  ThreadPractice2
//
//  Created by Duger on 13-10-15.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForthViewController : UIViewController<CustomViewDelegate>

@end
