//
//  NSThread+Addition.h
//  ThreadPractice
//
//  Created by Duger on 13-10-15.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSThread (Addition)
-(void)suspend;
-(void)resume;
@end
