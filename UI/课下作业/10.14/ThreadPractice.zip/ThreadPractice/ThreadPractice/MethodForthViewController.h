//
//  MethodForthViewController.h
//  ThreadPractice
//
//  Created by Duger on 13-10-14.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MethodForthViewController : UIViewController
@property (retain, nonatomic) IBOutlet UITextView *textView;
- (IBAction)didClickButton:(UIButton *)sender;

@end
