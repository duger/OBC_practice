//
//  MethodOneViewController.h
//  ThreadPractice
//
//  Created by Duger on 13-10-15.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MethodOneViewController : UIViewController
- (IBAction)didClickButton:(UIButton *)sender;
@property (retain, nonatomic) IBOutlet UITextView *textView;

@end
