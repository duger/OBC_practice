//
//  WFViewController.h
//  NewLightGame
//
//  Created by Duger on 13-9-14.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "customView.h"

@interface WFViewController : UIViewController<customViewDelegate>
-(void)showTheCount;
@end
