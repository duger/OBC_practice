//
//  WFViewController.h
//  NeonLineGame
//
//  Created by Duger on 13-9-13.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WFViewController : UIViewController
{
    NSTimer *timer;
}


@end
