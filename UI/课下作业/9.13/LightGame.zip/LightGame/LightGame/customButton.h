//
//  customButton.h
//  LightGame
//
//  Created by Duger on 13-9-13.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface customButton : UIView

@property(nonatomic,assign) UIButton *upButton;
@property(nonatomic,assign) UIButton *downButton;

@property(nonatomic,assign) NSInteger x;
@property(nonatomic,assign) NSInteger y;


@end
