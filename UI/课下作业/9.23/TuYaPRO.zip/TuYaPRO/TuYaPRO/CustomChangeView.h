//
//  CustomChangeView.h
//  TuYaPRO
//
//  Created by Duger on 13-9-24.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomChangeView : UIView
@property(nonatomic,retain) UIView *baseView;
@property(nonatomic,retain) UIView *changeView;
@property(nonatomic,retain) UITextField *titleTextField;

@end
