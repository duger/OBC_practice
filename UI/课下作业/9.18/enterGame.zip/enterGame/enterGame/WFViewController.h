//
//  WFViewController.h
//  enterGame
//
//  Created by Duger on 13-9-19.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WFViewController : UIViewController<UITextFieldDelegate,UIScrollViewDelegate>

@property(nonatomic,assign) NSInteger PointY;
@end
