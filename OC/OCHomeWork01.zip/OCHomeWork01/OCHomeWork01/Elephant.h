//
//  Elephant.h
//  OCHomeWork01
//
//  Created by Duger on 13-9-7.
//  Copyright (c) 2013年 Duger. All rights reserved.
//

#import "Animal.h"

@interface Elephant : Animal

@end
